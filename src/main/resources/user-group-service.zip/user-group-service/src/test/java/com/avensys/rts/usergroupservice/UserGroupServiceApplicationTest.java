package com.avensys.rts.usergroupservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserGroupServiceApplicationTest {
    @Test
    void contextLoads() {
    }
}
