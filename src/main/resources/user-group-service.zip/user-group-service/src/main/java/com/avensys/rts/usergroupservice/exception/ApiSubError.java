package com.avensys.rts.usergroupservice.exception;

public abstract class ApiSubError {

}
